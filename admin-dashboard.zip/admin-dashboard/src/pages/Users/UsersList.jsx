import UserManagement from "../../components/UserManagement";
import "./UsersList.css";

const UsersList = () => {
    return (
        <div>
            <UserManagement />
        </div>
    );
};

export default UsersList;
