import { Link } from "react-router-dom";

const Sidebar = () => {
    return (
        <div className="w-64 bg-gray-800 text-white p-4 h-screen fixed left-0 top-0 overflow-y-auto shadow-lg">
            <h2 className="text-2xl font-bold mb-4">Admin Dashboard</h2>
            <ul className="space-y-2">
                <li>
                    <Link to="/" className="block py-2 px-4 hover:bg-gray-700 rounded">
                        📊 Dashboard
                    </Link>
                </li>
                <li>
                    <Link to="/users" className="block py-2 px-4 hover:bg-gray-700 rounded">
                        👤 Quản lý người dùng
                    </Link>
                </li>
                <li>
                    <Link to="/orders" className="block py-2 px-4 hover:bg-gray-700 rounded">
                        📦 Quản lý đơn hàng
                    </Link>
                </li>
                <li>
                    <Link to="/categories" className="block py-2 px-4 hover:bg-gray-700 rounded">
                        🏷️ Quản lý danh mục
                    </Link>
                </li>
                <li>
                    <Link to="/products" className="block py-2 px-4 hover:bg-gray-700 rounded">
                        🛒 Quản lý sản phẩm
                    </Link>
                </li>
                <li>
                    <Link to="/reports" className="block py-2 px-4 hover:bg-gray-700 rounded">
                        📈 Báo cáo thống kê
                    </Link>
                </li>
            </ul>
        </div>
    );
};

export default Sidebar;
