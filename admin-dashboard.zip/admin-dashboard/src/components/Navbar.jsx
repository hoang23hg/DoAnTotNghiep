import { useNavigate } from "react-router-dom";

const Navbar = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem("isAdmin"); // Xóa trạng thái đăng nhập
        navigate("/login"); // Điều hướng về trang đăng nhập
    };

    return (
        <div className="bg-white shadow-md p-4 flex justify-between items-center">
            <h2 className="text-lg font-semibold">Quản trị viên</h2>
            <button 
                onClick={handleLogout} 
                className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition"
            >
                Đăng xuất
            </button>
        </div>
    );
};

export default Navbar;
