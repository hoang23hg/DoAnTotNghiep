package com.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit test for simple App.
 */
public class AppTest {

    /**
     * Test case: Kiểm tra logic đơn giản.
     */
    @Test
    public void testApp() {
        assertTrue(true);
    }
}
