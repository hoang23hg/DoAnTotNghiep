package com.example.backend.models;

import jakarta.persistence.*;

@Entity
@Table(name = "size")
public class Size {

    @Id
    @Column(name = "size_id")
    private Integer sizeId;

    @Enumerated(EnumType.STRING)
    @Column(name = "size_name", nullable = false)
    private SizeName sizeName;

    // Constructors
    public Size() {
    }

    public Size(Integer sizeId, SizeName sizeName) {
        this.sizeId = sizeId;
        this.sizeName = sizeName;
    }

    // Getters và Setters
    public Integer getSizeId() {
        return sizeId;
    }

    public void setSizeId(Integer sizeId) {
        this.sizeId = sizeId;
    }

    public SizeName getSizeName() {
        return sizeName;
    }

    public void setSizeName(SizeName sizeName) {
        this.sizeName = sizeName;
    }
}
