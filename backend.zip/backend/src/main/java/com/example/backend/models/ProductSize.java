package com.example.backend.models;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "product_size")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@IdClass(ProductSizeId.class) // Định nghĩa composite key
public class ProductSize {

    @Id
    @ManyToOne
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    @Id
    @ManyToOne
    @JoinColumn(name = "size_id", nullable = false)
    private Size size;

    @Column(nullable = false)
    private Integer stockQuantity;
}

// Định nghĩa khóa chính tổng hợp (Composite Key)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
class ProductSizeId implements Serializable {
    private Integer product;
    private Integer size;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductSizeId that = (ProductSizeId) o;
        return Objects.equals(product, that.product) && Objects.equals(size, that.size);
    }

    @Override
    public int hashCode() {
        return Objects.hash(product, size);
    }
}
