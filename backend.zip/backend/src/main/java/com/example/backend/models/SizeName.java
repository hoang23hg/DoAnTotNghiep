package com.example.backend.models;

public enum SizeName {
    S, M, L, XL, XXL
}
